// ✅✅ UPDATED CART CODE WITH localStorage SUPPORT ✅✅

// === ✅✅ LOGIN STATUS CHECK FROM SESSION (PHP) ===
function checkSessionStatus() {
  fetch("check_session.php")
    .then(res => res.json())
    .then(data => {
      if (data.loggedIn) {
        localStorage.setItem("userLoggedIn", "true");
      } else {
        localStorage.setItem("userLoggedIn", "false");
      }
    });
}
checkSessionStatus();


// === Helper Functions for localStorage Cart ===
function saveCartToLocalStorage() {
  const cartHTML = document.querySelector(".cart-content").innerHTML;
  localStorage.setItem("cartHTML", cartHTML);
  localStorage.setItem("totalPrice", document.querySelector(".total-price").innerText);
  localStorage.setItem("cartCount", document.querySelectorAll(".cart-box").length);
}

function loadCartFromLocalStorage() {
  const savedCart = localStorage.getItem("cartHTML");
  if (savedCart) {
    document.querySelector(".cart-content").innerHTML = savedCart;
    document.querySelector(".total-price").innerText = localStorage.getItem("totalPrice") || "₹0.00";
    updateCartCount();

    document.querySelectorAll(".cart-box").forEach(cartBox => {
      cartBox.querySelector(".cart-remove").addEventListener("click", removeCartItem);
      setupQuantityButtons(cartBox);
    });
  }
}

// Initialize Cart
let cartIcon = document.querySelector(".icon");
let cart = document.querySelector(".cart");
let closeCart = document.querySelector("#close-cart");
const cartCountElement = document.getElementById("cart-count");

// Open/Close Cart
cartIcon.addEventListener("click", () => cart.classList.toggle("active"));
closeCart.addEventListener("click", () => cart.classList.remove("active"));

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", ready);
} else {
  ready();
}

function ready() {
  loadCartFromLocalStorage();

  document.querySelectorAll(".btn").forEach(btn => {
    let product = btn.closest(".food-img");
    let title = product.querySelector("h1").innerText.trim();
    if ([...document.querySelectorAll(".cart-product-title")].some(p => p.innerText === title)) {
      btn.classList.add("added");
      btn.innerText = "Added";
      btn.disabled = true;
    }
  });

  document.querySelectorAll(".btn").forEach(button => {
    button.addEventListener("click", function (event) {
      addCartClicked(event);
      this.classList.add("added");
      this.innerText = "Added";
      this.disabled = true;
    });
  });

  document.querySelector(".btn-buy").addEventListener("click", (e) => {
    e.preventDefault();
    const isLoggedIn = localStorage.getItem("userLoggedIn");
    if (!isLoggedIn || isLoggedIn !== "true") {
      alert("🔹 कृपया पहले लॉगिन करें।");
      document.getElementById("signupModal").style.display = "flex";
      return;
    }
    document.querySelector(".cart").classList.remove("active");
    document.getElementById("orderForm").classList.add("active");
  });

  document.addEventListener("click", function (e) {
    if (e.target.classList.contains("cart-remove")) {
      removeCartItem(e);
    }
  });
}

function updateCartCount() {
  const count = document.querySelectorAll(".cart-box").length;
  cartCountElement.textContent = count;
}

function addCartClicked(event) {
  let product = event.target.closest(".food-img");
  let title = product.querySelector(".food-text h1").innerText;
  let price = product.querySelector(".price-value").innerText.trim().replace("₹", "");
  let weight = product.querySelector(".weight-value").innerText.trim();
  let image = product.querySelector("img").getAttribute("src");

  let cartItems = document.querySelector(".cart-content");
  let itemNames = cartItems.querySelectorAll(".cart-product-title");

  for (let name of itemNames) {
    if (name.innerText === title) {
      alert("Already in cart");
      return;
    }
  }

  let cartBox = document.createElement("div");
  cartBox.classList.add("cart-box", "cart-item");
  cartBox.innerHTML = `
    <img src="${image}" class="cart-img">
    <div class="detail-box">
      <div class="cart-product-title">${title}</div>
      <div><span class="cart-price">₹${price}</span> <span class="cart-weight">(${weight})</span></div>
      <div class="quantity-controls">
        <button class="qty-btn minus">-</button>
        <span class="qty-value">1</span>
        <button class="qty-btn plus">+</button>
      </div>
    </div>
    <i class="fa-solid fa-trash cart-remove"></i>
  `;

  cartItems.append(cartBox);
  cartBox.querySelector(".cart-remove").addEventListener("click", removeCartItem);
  setupQuantityButtons(cartBox);
  updateTotal();
  updateCartCount();
  saveCartToLocalStorage();
}

function setupQuantityButtons(cartBox) {
  const minusBtn = cartBox.querySelector(".minus");
  const plusBtn = cartBox.querySelector(".plus");
  const qtyValue = cartBox.querySelector(".qty-value");

  minusBtn.addEventListener("click", () => {
    let qty = parseInt(qtyValue.textContent);
    if (qty > 1) {
      qtyValue.textContent = qty - 1;
      updateTotal();
      saveCartToLocalStorage();
    }
  });

  plusBtn.addEventListener("click", () => {
    let qty = parseInt(qtyValue.textContent);
    if (qty < 10) {
      qtyValue.textContent = qty + 1;
      updateTotal();
      saveCartToLocalStorage();
    }
  });
}

function removeCartItem(event) {
  const buttonClicked = event.target;
  const cartItem = buttonClicked.closest('.cart-item');
  const title = cartItem.querySelector('.cart-product-title').innerText.trim();
  cartItem.remove();

  document.querySelectorAll(".food-img").forEach(card => {
    const name = card.querySelector("h1").innerText.trim();
    if (name === title) {
      const btn = card.querySelector(".btn");
      btn.innerText = "Add";
      btn.classList.remove("added");
      btn.disabled = false;
    }
  });

  updateTotal();
  updateCartCount();
  saveCartToLocalStorage();
}

function updateTotal() {
  let boxes = document.querySelectorAll(".cart-box");
  let total = 0;
  boxes.forEach(box => {
    let price = parseFloat(box.querySelector(".cart-price").innerText.replace("₹", ""));
    let qty = parseInt(box.querySelector(".qty-value").innerText);
    total += price * qty;
  });
  document.querySelector(".total-price").innerText = "₹" + total.toFixed(2);
}

document.getElementById("closeForm").addEventListener("click", () => {
  document.getElementById("orderForm").classList.remove("active");
});

function getCartData() {
  const items = document.querySelectorAll('.cart-content .cart-box');
  const cartItems = [];

  items.forEach(item => {
    const title = item.querySelector('.cart-product-title').innerText;
    const price = item.querySelector('.cart-price').innerText.replace('₹', '');
    const weight = item.querySelector('.cart-weight').innerText;
    const quantity = item.querySelector('.qty-value').innerText;

    cartItems.push({
      name: title,
      price: parseFloat(price),
      weight: weight,
      quantity: parseInt(quantity)
    });
  });

  return cartItems;
}

function checkBeforeOrder() {
  const isLoggedIn = localStorage.getItem("userLoggedIn");
  if (!isLoggedIn || isLoggedIn !== "true") {
    alert("कृपया पहले लॉगिन करें।");
    document.getElementById("signupModal").style.display = "flex";
    return;
  }

  const form = document.getElementById("checkoutForm");
  const name = form.querySelector('input[placeholder="Full Name"]').value.trim();
  const phone = form.querySelector('input[placeholder="Phone Number"]').value.trim();
  const address = form.querySelector('textarea[placeholder="Address"]').value.trim();
  const cartItems = getCartData();

  if (!name || !phone || !address || cartItems.length === 0) {
    alert("Please fill all fields and add items.");
    return;
  }

  let order = {
    name,
    phone,
    address,
    location: "",
    products: cartItems
  };

  getUserLocation((locationLink) => {
    order.location = locationLink;

    fetch("save_order.php", {
      method: "POST",
      body: JSON.stringify(order),
      headers: { "Content-Type": "application/json" },
    })
    .then(res => res.text())
    .then(response => {
      alert("✅ " + response);
      document.querySelector(".cart-content").innerHTML = "";
      document.querySelector(".total-price").innerText = "₹0.00";
      updateCartCount();
      document.getElementById("orderForm").classList.remove("active");
      localStorage.removeItem("cartHTML");
      localStorage.removeItem("totalPrice");
      localStorage.removeItem("cartCount");

      document.querySelectorAll(".btn").forEach(btn => {
        btn.disabled = false;
        btn.innerText = "Add";
        btn.classList.remove("added");
      });
    })
    .catch(err => {
      console.error("Order error:", err);
      alert("❌ Failed to place order!");
    });
  });
}


function getUserLocation(callback) {
  if ("geolocation" in navigator) {
    navigator.geolocation.getCurrentPosition(
      position => {
        const link = `https://www.google.com/maps?q=${position.coords.latitude},${position.coords.longitude}`;
        callback(link);
      },
      error => {
        console.warn("Location error:", error);
        callback("Location not available");
      }
    );
  } else {
    callback("Geolocation not supported");
  }
}

function isUserLoggedIn() {
  return localStorage.getItem("userLoggedIn") === "true";
}
