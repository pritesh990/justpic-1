<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
  header("Location: login.php");
  exit();
}
include("../includes/db.php");

// Get & sanitize date range
$from = $_POST['from'] ?? date("Y-m-d");
$to = $_POST['to'] ?? date("Y-m-d");

// Validate date format (basic check)
if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $from) || !preg_match("/^\d{4}-\d{2}-\d{2}$/", $to)) {
  die("Invalid date format.");
}

// Prepare order query
$stmt = $conn->prepare("SELECT * FROM orders WHERE order_date BETWEEN ? AND ? ORDER BY id DESC");
$stmt->bind_param("ss", $from, $to);
$stmt->execute();
$result = $stmt->get_result();

// Excel download header
$filename = "Justpic_Orders_" . date("Ymd_His") . ".xls";
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"$filename\"");

// Excel table heading
echo "Order ID\tDate\tCustomer\tPhone\tTotal\tItems\n";

// Process each order
while ($order = $result->fetch_assoc()) {
  $oid = $order['id'];
  $items = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
  $items->bind_param("i", $oid);
  $items->execute();
  $itemResult = $items->get_result();

  $itemList = "";
  while ($item = $itemResult->fetch_assoc()) {
    $pname = str_replace(["\t", "\n", "\r"], " ", $item['product_name']);
    $weight = str_replace(["\t", "\n", "\r"], " ", $item['weight']);
    $qty = $item['quantity'];
    $sub = number_format($item['subtotal'], 2);
    $itemList .= "$pname ($weight) × $qty = ₹$sub; ";
  }

  $id = $order['id'];
  $date = $order['order_date'];
  $name = str_replace(["\t", "\n", "\r"], " ", $order['customer_name']);
  $phone = $order['phone'];
  $total = number_format($order['total_amount'], 2);

  echo "$id\t$date\t$name\t$phone\t₹$total\t$itemList\n";
}
exit();
?>
