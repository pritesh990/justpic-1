<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
  header("Location: login.php");
  exit();
}

include("../includes/db.php");

// Check if editing
$editMode = false;
$editData = null;

if (isset($_GET['edit'])) {
  $editMode = true;
  $editID = intval($_GET['edit']);
  $editData = $conn->query("SELECT * FROM products WHERE id = $editID")->fetch_assoc();

  if (!$editData) {
    echo "<p style='color:red;'>❌ Product not found for editing.</p>";
    $editMode = false;
  }
}

// ADD PRODUCT
if (isset($_POST['add'])) {
  $name = htmlspecialchars(trim($_POST['name']));
  $category = htmlspecialchars(trim($_POST['category']));
  $price = floatval($_POST['price']);
  $old_price = floatval($_POST['old_price']);
  $weight = htmlspecialchars(trim($_POST['weight']));
  $quantity = htmlspecialchars(trim($_POST['quantity']));
  $discount = htmlspecialchars(trim($_POST['discount_text']));

  $imgName = $_FILES['image']['name'];
  $imgTmp = $_FILES['image']['tmp_name'];
  $imgExt = strtolower(pathinfo($imgName, PATHINFO_EXTENSION));
  $allowed = ['jpg', 'jpeg', 'png', 'gif'];

  if (in_array($imgExt, $allowed)) {
    $newImgName = uniqid() . '.' . $imgExt;
    move_uploaded_file($imgTmp, "../uploads/$newImgName");

    $stmt = $conn->prepare("INSERT INTO products (name, category, price, old_price, weight, quantity, image, discount_text) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssddssss", $name, $category, $price, $old_price, $weight, $quantity, $newImgName, $discount);

    if ($stmt->execute()) {
      echo "<p style='color:green;'>✅ Product added successfully!</p>";
    } else {
      echo "<p style='color:red;'>❌ Error adding product.</p>";
    }
  } else {
    echo "<p style='color:red;'>❌ Invalid image format.</p>";
  }
}

// UPDATE PRODUCT
if (isset($_POST['update'])) {
  $id = intval($_POST['product_id']);
  $name = htmlspecialchars(trim($_POST['name']));
  $category = htmlspecialchars(trim($_POST['category']));
  $price = floatval($_POST['price']);
  $old_price = floatval($_POST['old_price']);
  $weight = htmlspecialchars(trim($_POST['weight']));
  $quantity = htmlspecialchars(trim($_POST['quantity']));
  $discount = htmlspecialchars(trim($_POST['discount_text']));

  $getOld = $conn->query("SELECT image FROM products WHERE id = $id");
  $oldImage = $getOld->fetch_assoc()['image'];

  if ($_FILES['image']['name']) {
    $imgName = $_FILES['image']['name'];
    $imgTmp = $_FILES['image']['tmp_name'];
    $imgExt = strtolower(pathinfo($imgName, PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'gif'];

    if (!in_array($imgExt, $allowed)) {
      echo "<p style='color:red;'>❌ Invalid image format.</p>";
      exit();
    }

    $newImgName = uniqid() . '.' . $imgExt;
    move_uploaded_file($imgTmp, "../uploads/$newImgName");
    if (file_exists("../uploads/$oldImage")) unlink("../uploads/$oldImage");
  } else {
    $newImgName = $oldImage;
  }

  $stmt = $conn->prepare("UPDATE products SET name=?, category=?, price=?, old_price=?, weight=?, quantity=?, image=?, discount_text=? WHERE id=?");
  $stmt->bind_param("ssddssssi", $name, $category, $price, $old_price, $weight, $quantity, $newImgName, $discount, $id);

  if ($stmt->execute()) {
    echo "<p style='color:green;'>✅ Product updated successfully!</p>";
    // Refresh edit data
    $editData = $conn->query("SELECT * FROM products WHERE id = $id")->fetch_assoc();
  } else {
    echo "<p style='color:red;'>❌ Failed to update product.</p>";
  }
}

// DELETE PRODUCT
if (isset($_GET['delete'])) {
  $id = intval($_GET['delete']);

  $getImg = $conn->query("SELECT image FROM products WHERE id = $id");
  if ($getImg && $getImg->num_rows > 0) {
    $imgData = $getImg->fetch_assoc();
    $imgPath = "../uploads/" . $imgData['image'];
    if (file_exists($imgPath)) {
      unlink($imgPath);
    }
  }

  $conn->query("DELETE FROM products WHERE id = $id");
  echo "<p style='color:red;'>❌ Product deleted!</p>";
}

// FETCH ALL PRODUCTS
$result = $conn->query("SELECT * FROM products ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Add Product - Justpic Admin</title>
  <link rel="stylesheet" href="../assets/justpic.css">
  <style>
    body { padding: 30px; font-family: Arial; background: #f8f9fa; }
    h2 { margin-bottom: 20px; }
    form input, form select {
      padding: 10px;
      margin: 8px 0;
      width: 100%;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    form input[type="submit"] {
      background-color: #022a45;
      color: white;
      border: none;
      cursor: pointer;
    }
    table { width: 100%; border-collapse: collapse; margin-top: 30px; }
    th, td {
      border: 1px solid #999;
      padding: 10px;
      text-align: center;
    }
    .img-thumb {
      width: 80px;
    }
    .actions a {
      margin: 0 5px;
      text-decoration: none;
    }
  </style>
</head>
<body>

  <h2><?= $editMode ? '✏️ Edit Product' : '🧺 Add Veg-fru Product' ?></h2>

  <form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="product_id" value="<?= $editMode ? $editID : '' ?>">

    <input type="text" name="name" placeholder="Product Name" value="<?= $editMode ? htmlspecialchars($editData['name']) : '' ?>" required>

    <select name="category" required>
      <option value="">-- Select Category --</option>
      <option value="vegetable" <?= $editMode && $editData['category'] === 'vegetable' ? 'selected' : '' ?>>Vegetable</option>
      <option value="fruit" <?= $editMode && $editData['category'] === 'fruit' ? 'selected' : '' ?>>Fruit</option>
    </select>

    <input type="number" step="0.01" name="price" placeholder="Current Price" value="<?= $editMode ? $editData['price'] : '' ?>" required>
    <input type="number" step="0.01" name="old_price" placeholder="Old Price" value="<?= $editMode ? $editData['old_price'] : '' ?>">
    <input type="text" name="weight" placeholder="Weight (e.g. 1kg, 500g)" value="<?= $editMode ? $editData['weight'] : '' ?>" required>
    <input type="text" name="discount_text" placeholder="Discount (e.g. 10% OFF)" value="<?= $editMode ? $editData['discount_text'] : '' ?>">
    <input type="text" name="quantity" placeholder="Available Quantity" value="<?= $editMode ? $editData['quantity'] : '' ?>" required>

    <?php if ($editMode): ?>
      <p>Current Image:</p>
      <img src="../uploads/<?= $editData['image'] ?>" width="100"><br><br>
    <?php endif; ?>

    <input type="file" name="image" accept="image/*" <?= $editMode ? '' : 'required' ?>>

    <input type="submit" name="<?= $editMode ? 'update' : 'add' ?>" value="<?= $editMode ? 'Update Product' : 'Add Product' ?>">
  </form>

  <h2>📃 All Products</h2>
  <table>
    <tr>
      <th>#</th>
      <th>Image</th>
      <th>Name</th>
      <th>Category</th>
      <th>Price</th>
      <th>Old Price</th>
      <th>Weight</th>
      <th>Quantity</th>
      <th>Actions</th>
    </tr>
    <?php $i=1; while($row = $result->fetch_assoc()): ?>
    <tr>
      <td><?= $i++ ?></td>
      <td><img src="../uploads/<?= htmlspecialchars($row['image']) ?>" class="img-thumb"></td>
      <td><?= htmlspecialchars($row['name']) ?></td>
      <td><?= htmlspecialchars($row['category']) ?></td>
      <td>₹<?= number_format($row['price'], 2) ?></td>
      <td><s>₹<?= number_format($row['old_price'], 2) ?></s></td>
      <td><?= htmlspecialchars($row['weight']) ?></td>
      <td><?= htmlspecialchars($row['quantity']) ?></td>
      <td class="actions">
        <a href="add_product.php?edit=<?= $row['id'] ?>" style="color:orange;">✏️ Edit</a> |
        <a href="add_product.php?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this product?')" style="color:red;">🗑 Delete</a>
      </td>
    </tr>
    <?php endwhile; ?>
  </table>

  <a href="logout.php" style="position: absolute; top: 20px; right: 20px; padding: 10px; background: red; color: white; text-decoration: none; border-radius: 5px;">
    🔓 Logout
  </a>

  <a href="dashboard.php" style="display:inline-block; margin-top: 20px; text-decoration: none; color: blue;">⬅️ Back to Product List</a>


</body>
</html>
