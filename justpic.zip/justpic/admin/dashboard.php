<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
  header("Location: login.php");
  exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Justpic Admin Dashboard</title>
  <link rel="stylesheet" href="../assets/justpic.css">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: #f8f9fa;
      padding: 40px;
      text-align: center;
    }

    h1 {
      color: #022a45;
      margin-bottom: 40px;
    }

    .admin-cards {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 30px;
    }

    .card {
      background: white;
      padding: 30px;
      width: 250px;
      border-radius: 15px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.1);
      transition: 0.3s ease;
      text-decoration: none;
      color: #022a45;
    }

    .card:hover {
      transform: translateY(-5px);
      background-color: #eafbf7;
    }

    .card h2 {
      font-size: 22px;
      margin: 10px 0;
    }

    .card p {
      font-size: 14px;
      color: #666;
    }

    .logout-btn {
      position: absolute;
      top: 20px;
      right: 20px;
      background: red;
      color: white;
      padding: 10px 15px;
      border-radius: 5px;
      text-decoration: none;
      font-weight: bold;
    }
  </style>
</head>
<body>

  <a class="logout-btn" href="logout.php">🔓 Logout</a>

  <h1>🛠️ Justpic Admin Panel</h1>

  <div class="admin-cards">
    <a href="add_product.php" class="card">
      <h2>🧺 Add Veg-fru</h2>
      <p>Add, edit or delete vegetables</p>
    </a>


    <a href="manage_orders.php" class="card">
      <h2>📦 Manage Orders</h2>
      <p>View & filter user orders</p>
    </a>

    <a href="daily_report.php" class="card">
      <h2>📊 Daily Report</h2>
      <p>Check quantity of items sold</p>
    </a>

    <a href="users.php" class="card">
      <h2>📊 Register User</h2>
      <p>Check quantity of items sold</p>
    </a>
  </div>

</body>
</html>
