<?php
include("../includes/db.php"); // डेटाबेस कनेक्शन
include("../includes/session.php"); // सेशन स्टार्ट

// 🔍 Search functionality
$search = '';
if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
    $stmt = $conn->prepare("SELECT * FROM users WHERE phone LIKE ? ORDER BY created_at DESC");
    $like = "%$search%";
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM users ORDER BY created_at DESC");
}

// 🗑️ Delete user
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM users WHERE id = $id");
    header("Location: users.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Registered Users – Admin Panel</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 30px;
      background: #f9f9f9;
    }
    h2 {
      text-align: center;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      background: white;
      box-shadow: 0 0 10px #ccc;
    }
    th, td {
      padding: 12px 15px;
      border: 1px solid #ddd;
      text-align: left;
    }
    th {
      background-color: #007bff;
      color: white;
    }
    tr:hover {
      background-color: #f1f1f1;
    }
    .search-box {
      text-align: center;
      margin-bottom: 20px;
    }
    .search-box input {
      padding: 8px;
      width: 250px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
    .search-box button {
      padding: 8px 12px;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    .delete-btn {
      background: #dc3545;
      color: white;
      padding: 6px 10px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <h2>📋 Registered Users</h2>

  <div class="search-box">
    <form method="GET" action="users.php">
      <input type="text" name="search" placeholder="Search by phone..." value="<?= htmlspecialchars($search) ?>">
      <button type="submit">Search</button>
    </form>
  </div>

  <table>
    <tr>
      <th>#</th>
      <th>Full Name</th>
      <th>Phone Number</th>
      <th>Signup Date</th>
      <th>Action</th>
    </tr>
    <?php
    $i = 1;
    while ($row = $result->fetch_assoc()):
    ?>
    <tr>
      <td><?= $i++ ?></td>
      <td><?= htmlspecialchars($row['name']) ?></td>
      <td><?= htmlspecialchars($row['phone']) ?></td>
      <td><?= htmlspecialchars($row['created_at']) ?></td>
      <td>
        <a href="users.php?delete=<?= $row['id'] ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
      </td>
    </tr>
    <?php endwhile; ?>
  </table>
</body>
</html>
