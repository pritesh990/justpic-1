<?php
session_start();

$error = "";

// Dummy stored credentials (replace with DB or hashed in future)
define("ADMIN_USER", "admin");
define("ADMIN_PASS", "1234");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = trim($_POST['username']);
  $password = trim($_POST['password']);

  if ($username === ADMIN_USER && $password === ADMIN_PASS) {
    $_SESSION['admin_logged_in'] = true;
    header("Location: dashboard.php");
    exit();
  } else {
    $error = "❌ Invalid username or password!";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Login - Justpic</title>
  <link rel="stylesheet" href="../assets/justpic.css">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: #f0f0f0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .login-box {
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.2);
      width: 100%;
      max-width: 400px;
      text-align: center;
    }
    input {
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
    button {
      background: #022a45;
      color: white;
      padding: 12px;
      border: none;
      width: 100%;
      border-radius: 5px;
      font-size: 16px;
    }
    button:hover {
      background: #28a745;
    }
    .error {
      color: red;
      margin-bottom: 10px;
      font-weight: bold;
    }
  </style>
</head>
<body>

<div class="login-box">
  <h2>🔐 Admin Login</h2>
  <?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  <form method="POST">
    <input type="text" name="username" placeholder="Username" required />
    <input type="password" name="password" placeholder="Password" required />
    <button type="submit">Login</button>
  </form>
</div>

</body>
</html>
