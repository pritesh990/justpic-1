<?php
session_start();
session_unset();      // Optional: Clear all session variables
session_destroy();    // Destroys the session

header("Location: login.php");
exit();
