<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
  header("Location: login.php");
  exit();
}
include("../includes/db.php");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Manage Orders - Justpic Admin</title>
  <link rel="stylesheet" href="../assets/justpic.css">
  <style>
    body { font-family: Arial; padding: 30px; background: #f8f9fa; }
    h2 { margin-bottom: 20px; }
    form { margin-bottom: 30px; }
    input[type="date"], input[type="submit"], button {
      padding: 10px;
      margin-right: 10px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      background: #fff;
    }
    th, td {
      border: 1px solid #ccc;
      padding: 10px;
      text-align: left;
    }
    th { background-color: #022a45; color: white; }
    ul { margin: 0; padding-left: 15px; }
    .total-section {
      margin-top: 20px;
      font-weight: bold;
      font-size: 18px;
      color: green;
    }
  </style>
</head>
<body>

<h2>📦 Manage Customer Orders</h2>

<form method="GET">
  <label>From:</label>
  <input type="date" name="from_date" required value="<?= htmlspecialchars($_GET['from_date'] ?? '') ?>">
  <label>To:</label>
  <input type="date" name="to_date" required value="<?= htmlspecialchars($_GET['to_date'] ?? '') ?>">
  <input type="submit" value="Filter">
</form>

<?php
$from = $_GET['from_date'] ?? date("Y-m-d");
$to = $_GET['to_date'] ?? date("Y-m-d");

if ($from > $to) {
    echo "<p style='color:red;'>⚠️ Invalid date range selected.</p>";
    exit;
}

$stmt = $conn->prepare("SELECT * FROM orders WHERE order_date BETWEEN ? AND ? ORDER BY id DESC");
$stmt->bind_param("ss", $from, $to);
$stmt->execute();
$result = $stmt->get_result();
$total_amount = 0;
?>

<form method="POST" action="export.php" style="margin-bottom: 20px;">
  <input type="hidden" name="from" value="<?= htmlspecialchars($from) ?>">
  <input type="hidden" name="to" value="<?= htmlspecialchars($to) ?>">
  <button type="submit" style="background: green; color: white;">⬇ Export to Excel</button>
</form>

<?php if ($result->num_rows > 0): ?>
<table>
  <tr>
    <th>#</th>
    <th>Date</th>
    <th>Order ID</th>
    <th>Customer</th>
    <th>Phone</th>
    <th>Address</th>
    <th>Location</th>
    <th>Total</th>
    <th>Items</th>
    <th>Print</th>
  </tr>

  <?php $i = 1; while($row = $result->fetch_assoc()): ?>
    <tr>
      <td><?= $i++ ?></td>
      <td><?= htmlspecialchars($row['order_date']) ?></td>
      <td><?= htmlspecialchars($row['order_id']) ?></td>
      <td><?= htmlspecialchars($row['customer_name']) ?></td>
      <td><?= htmlspecialchars($row['phone']) ?></td>
      <td><?= htmlspecialchars($row['address']) ?></td>
      <td>
        <?php if (!empty($row['location_link'])): ?>
          <a href="<?= htmlspecialchars($row['location_link']) ?>" target="_blank">📍 Map</a>
        <?php else: ?>
          -
        <?php endif; ?>
      </td>
      <td>₹<?= number_format($row['total_amount'], 2) ?></td>
      <td>
        <ul>
          <?php
            // ✅ Use 'id' (INT) to link to order_items table
            $oid = $row['id'];
            $itemStmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
            $itemStmt->bind_param("i", $oid);
            $itemStmt->execute();
            $itemRes = $itemStmt->get_result();
            if ($itemRes->num_rows > 0) {
              while($item = $itemRes->fetch_assoc()):
          ?>
            <li><?= htmlspecialchars($item['product_name']) ?> (<?= $item['weight'] ?>) × <?= $item['quantity'] ?> = ₹<?= number_format($item['subtotal'], 2) ?></li>
          <?php endwhile;
            } else {
              echo "<li><i>No items found</i></li>";
            }
          ?>
        </ul>
      </td>
      <td><a href="print_invoice.php?order_id=<?= $row['id'] ?>" target="_blank">🖨 Print</a></td>
    </tr>
    <?php $total_amount += $row['total_amount']; ?>
  <?php endwhile; ?>
</table>

<div class="total-section">
  ✅ Total Orders Amount from <?= htmlspecialchars($from) ?> to <?= htmlspecialchars($to) ?>: ₹<?= number_format($total_amount, 2) ?>
</div>
<?php else: ?>
  <p style="color: red;">❌ No orders found between the selected dates.</p>
<?php endif; ?>

</body>
</html>
