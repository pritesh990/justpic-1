<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
  header("Location: login.php");
  exit();
}

include("../includes/db.php");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Daily Vegetable Report - Justpic Admin</title>
  <link rel="stylesheet" href="../assets/justpic.css">
  <style>
    body { font-family: Arial; padding: 30px; background: #f8f9fa; }
    h2 { margin-bottom: 20px; }
    input[type="date"], input[type="submit"] {
      padding: 10px;
      margin-right: 10px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      background: #fff;
    }
    th, td {
      border: 1px solid #ccc;
      padding: 10px;
      text-align: left;
    }
    th {
      background-color: #022a45;
      color: white;
    }
    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
    .no-data {
      color: red;
      margin-top: 20px;
    }
  </style>
</head>
<body>

<h2>📊 Daily Vegetable Quantity Summary</h2>

<form method="GET">
  <label>Select Date:</label>
  <input type="date" name="report_date" required value="<?= htmlspecialchars($_GET['report_date'] ?? date('Y-m-d')) ?>">
  <input type="submit" value="Show Report">
</form>

<?php
$reportDate = $_GET['report_date'] ?? date("Y-m-d");

// Prepare query safely
$stmt = $conn->prepare("
  SELECT oi.product_name, oi.weight, SUM(oi.quantity) as total_qty 
  FROM orders o 
  JOIN order_items oi ON o.id = oi.order_id 
  WHERE o.order_date = ?
  GROUP BY oi.product_name, oi.weight
  ORDER BY oi.product_name ASC
");

$stmt->bind_param("s", $reportDate);
$stmt->execute();
$result = $stmt->get_result();
?>

<?php if ($result->num_rows > 0): ?>
<table>
  <tr>
    <th>#</th>
    <th>Product</th>
    <th>Weight Per Item</th>
    <th>Total Quantity Ordered</th>
  </tr>
  <?php $i = 1; while($row = $result->fetch_assoc()): ?>
  <tr>
    <td><?= $i++ ?></td>
    <td><?= htmlspecialchars($row['product_name']) ?></td>
    <td><?= htmlspecialchars($row['weight']) ?></td>
    <td><?= number_format($row['total_qty'] ?? 0) ?></td>
  </tr>
  <?php endwhile; ?>
</table>
<?php else: ?>
<p class="no-data">❌ No orders found on <?= htmlspecialchars($reportDate) ?>.</p>
<?php endif; ?>

</body>
</html>
