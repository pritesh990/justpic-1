<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
  header("Location: login.php");
  exit();
}
include("../includes/db.php");

if (!isset($_GET['order_id'])) {
  die("Order ID missing.");
}

$order_id = intval($_GET['order_id']);

// Fetch order securely
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
if (!$order) {
  die("Order not found.");
}

// Fetch items securely
$itemStmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
$itemStmt->bind_param("i", $order_id);
$itemStmt->execute();
$items = $itemStmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Invoice #<?= htmlspecialchars($order_id) ?></title>
  <style>
    body {
      font-family: 'Arial', sans-serif;
      padding: 40px;
      max-width: 800px;
      margin: auto;
    }

    h1, h3 {
      text-align: center;
    }

    .info {
      margin: 30px 0;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      font-size: 15px;
    }

    th, td {
      border: 1px solid #ccc;
      padding: 10px;
      text-align: left;
    }

    th {
      background: #022a45;
      color: white;
    }

    .total {
      text-align: right;
      font-weight: bold;
      font-size: 18px;
      margin-top: 30px;
    }

    .print-btn {
      margin: 20px 0;
      display: block;
      text-align: right;
    }

    .print-btn button {
      background-color: #28a745;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      font-size: 14px;
      cursor: pointer;
    }

    .print-btn button:hover {
      background: #1e7e34;
    }
  </style>
</head>
<body>

<div class="print-btn">
  <button onclick="window.print()">🖨 Print / Save as PDF</button>
</div>

<h1>Justpic - Order Invoice</h1>
<h3>Order ID: #<?= htmlspecialchars($order_id) ?> | Date: <?= htmlspecialchars($order['order_date']) ?></h3>

<div class="info">
  <strong>Customer:</strong> <?= htmlspecialchars($order['customer_name']) ?><br>
  <strong>Phone:</strong> <?= htmlspecialchars($order['phone']) ?><br>
  <strong>Address:</strong> <?= htmlspecialchars($order['address']) ?><br>
  <strong>Location:</strong>
  <?php if (!empty($order['location_link'])): ?>
    <a href="<?= htmlspecialchars($order['location_link']) ?>" target="_blank">View Map</a><br>
  <?php else: ?>
    Not provided<br>
  <?php endif; ?>
</div>

<table>
  <tr>
    <th>#</th>
    <th>Product</th>
    <th>Weight</th>
    <th>Qty</th>
    <th>Price</th>
    <th>Subtotal</th>
  </tr>
  <?php $i = 1; $total = 0; while($item = $items->fetch_assoc()): ?>
  <tr>
    <td><?= $i++ ?></td>
    <td><?= htmlspecialchars($item['product_name']) ?></td>
    <td><?= htmlspecialchars($item['weight']) ?></td>
    <td><?= $item['quantity'] ?></td>
    <td>₹<?= number_format($item['price'], 2) ?></td>
    <td>₹<?= number_format($item['subtotal'], 2) ?></td>
  </tr>
  <?php $total += $item['subtotal']; endwhile; ?>
</table>

<p class="total">Total Amount: ₹<?= number_format($total, 2) ?></p>

</body>
</html>
