<?php
session_start();
session_destroy();
echo "<script>
  localStorage.removeItem('userLoggedIn');
  window.location.href = 'home.php';
</script>";
?>
