<?php include("includes/session.php"); ?>
<?php
include("includes/db.php");

$result = $conn->query("SELECT * FROM products WHERE category = 'fruit' ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Justpic - Fruits</title>
  <link rel="stylesheet" href="assets/justpic.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

</head>
<body>

<!-- Header -->
<header class="head">
  <div class="header-container">

  
    <div class="left">
      <img src="uploads/logo.png" alt="Logo" />
    </div>

 
<div id="signupModal">
  <div>
    <h3>Signup to continue</h3>
    <input id="signupName" placeholder="Your Name">
    <input id="signupPhone" placeholder="Phone Number">
    <button onclick="submitSignup()">Submit</button>
    <button onclick="document.getElementById('signupModal').style.display='none'">✖</button>
  </div>
</div>


    <div class="right">
  <?php if (isset($_SESSION['user'])): ?>
    <span class="welcome-text">👋 <?= htmlspecialchars($_SESSION['user']['name']) ?></span>
    <a href="logout.php" class="signup-btn">Logout</a>
  <?php else: ?>
    <button class="signup-btn" onclick="document.getElementById('signupModal').style.display='block'">Signup</button>
  <?php endif; ?>

  <div class="icon">
    <i class="fa-solid fa-cart-shopping"></i>
    <span class="cart-count" id="cart-count">0</span>
  </div>
</div>

    
</div>
</header>

<div class="middle">
      <div class="search-container">
        <input type="text" id="searchInput" placeholder="Search products..." />
      </div>
    </div>


<a href="home.php" style="display:inline-block; margin-top: 20px; text-decoration: none; color: blue;">⬅️ Back to Product List</a>


<!--<div class="filter-bar">
  <a href="index.php" class="filter-btn"id="fil-btn">All</a>
  <a href="index.php?category=vegetable" class="filter-btn">Vegetables</a>
  <a href="index.php?category=fruit" class="filter-btn">Fruits</a>
</div>-->

<!-- Cart section  -->
<div class="cart">
  <h2 class="cart-title">Your Cart</h2>
  <div class="cart-content"></div>

  <div class="cart-sp">
    <div class="total">
      <div class="total-title">Total</div>
      <span class="total-price">₹0.00</span>
    </div>  

    <div class="cart-imp">
      <h5>(1) ન્યૂનતમ ઓર્ડર ₹70 રૂપિયા નો હોવો જોયે</h5>
      <h5>(2) ₹99 સુધી ના Order પર delivery ચાર્જ ₹20</h5>
      <h5>(3) ₹100 ઉપર ના Order પર delivery ચાર્જ Free</h5>
    </div>

    <span class="times">*ડિલિવરી સવારે 9 AM થી 11 AM વાગ્ય સુધીમાં પોહચાડી દેવાશે.*</span>
    <button type="button" class="btn-buy">Buy Now</button>
  </div> 

  <i class="fa-solid fa-xmark" id="close-cart"></i>
</div>

<!-- Order Form -->
<div class="order-form" id="orderForm">
  <div class="form-content">
    <h2>Place Your Order</h2>
    <form id="checkoutForm">
      <input type="text" placeholder="Full Name" required />
      <input type="tel" placeholder="Phone Number" required />
      <textarea placeholder="Address" rows="4" required></textarea>
      <button type="button" class="order-btn" onclick="checkBeforeOrder()">Order</button>
      <button type="button" id="closeForm" class="close-btn">Cancel</button>
    </form>
  </div>
</div>
  
  

<!--  Product Section -->
<section class="section">
  <div class="food">
  <?php
    while ($row = $result->fetch_assoc()):
      $name = htmlspecialchars($row['name']);
      $price = number_format($row['price'], 2);
      $old_price = number_format($row['old_price'], 2);
      $weight = htmlspecialchars($row['weight']);
      $image = htmlspecialchars($row['image']);
    ?>
      <div class="food-img product-card">
        <?php if (!empty($row['discount_text'])): ?>
          <span class="discount-badge"><?= htmlspecialchars($row['discount_text']) ?></span>
        <?php endif; ?>
        <img src="uploads/<?php echo $image; ?>" alt="<?php echo $name; ?>" />
        
        <div class="food-text">
          <h1 class="title"><?php echo $name; ?></h1>
          <h3>
            <span class="price price-value">₹<?php echo $price; ?></span>
            <span class="old-price">₹<?php echo $old_price; ?></span>
            <span class="weight-value">(<?php echo $weight; ?>)</span>
          </h3>
          <button class="btn">Add</button>
        </div>
      </div>
    <?php endwhile; ?>
  </div>
</section>


<style>
   
/* header */

body {
      font-family: Arial, sans-serif;
      
}
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.head {
  width: 100%;
  background-color: #fff;
  position: sticky;
  top: 0;
  z-index: 1000;
 /* box-shadow: 0 1px 5px rgba(0, 0, 0, 0.05);*/
}

.header-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
}

.left img {
  height: 60px;
}

.middle {
  flex: 1;
  display: flex;
  justify-content: center;
  padding: 0 20px;
}

.search-container {
  width: 100%;
  max-width: 400px;
}

#searchInput {
  width: 100%;
  padding: 10px 20px;
  border: 2px solid #004f9e;
  border-radius: 30px;
  outline: none;
  font-size: 14px;
  transition: 0.3s ease;
  box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}

#searchInput:focus {
  border-color: #022a45;
  box-shadow: 0 6px 18px rgba(0,79,158,0.25);
}

.right {
  display: flex;
  align-items: center;
}

.icon {
  font-size: 1.8em;
  position: relative;
  cursor: pointer;
}

.icon:hover {
  color: #004f9e;
  transition: 0.3s ease;
}

#cart-count {
  position: absolute;
  top: -10px;
  right: -14px;
  background: red;
  color: white;
  font-size: 12px;
  padding: 4px 6px;
  border-radius: 50%;
}

.right {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-right: 10px;
}

.signup-btn {
  background: #0d6efd;
  color: white;
  padding: 6px 12px;
  border-radius: 6px;
  border: none;
  cursor: pointer;
  font-size: 13px;
  font-weight: 500;
  transition: 0.3s ease;
}

.signup-btn:hover {
  background: #0b5ed7;
}


 #signupModal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(4px);
    z-index: 999;
    animation: fadeIn 0.3s ease-in-out;
  }

  #signupModal > div {
    background: #fff;
    max-width: 420px;
    margin: 80px auto;
    padding: 25px 30px;
    border-radius: 12px;
    position: relative;
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    animation: slideIn 0.4s ease-in-out;
  }

  #signupModal h3 {
    margin-top: 0;
    font-size: 20px;
    font-weight: 600;
    color: #333;
    text-align: center;
  }

  #signupModal input {
    width: 100%;
    padding: 12px;
    margin-top: 12px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 14px;
    transition: border 0.3s;
  }

  #signupModal input:focus {
    outline: none;
    border-color: #4CAF50;
    box-shadow: 0 0 5px #4CAF50;
  }

  #signupModal button {
    padding: 10px 22px;
    margin-top: 15px;
    border: none;
    background: #4CAF50;
    color: white;
    font-size: 14px;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s;
  }

  #signupModal button:hover {
    background: #43a047;
  }

  #signupModal button:last-child {
    position: absolute;
    top: 12px;
    right: 12px;
    background: transparent;
    color: #888;
    font-size: 18px;
    padding: 0;
    width: 32px;
    height: 32px;
    line-height: 32px;
    border-radius: 50%;
    transition: background 0.3s, color 0.3s;
  }

  #signupModal button:last-child:hover {
    background: #f2f2f2;
    color: #000;
  }

  @keyframes fadeIn {
    from {opacity: 0;}
    to {opacity: 1;}
  }

  @keyframes slideIn {
    from {transform: translateY(-30px); opacity: 0;}
    to {transform: translateY(0); opacity: 1;}
  }




/* cart */

.cart {
  position: fixed;
  top: 0;
  right: -100%;
  width: 360px;
  height: 100vh;
  padding: 20px 0 0 0; /* remove bottom padding */
  background: #fff;
  box-shadow: -2px 0 4px rgba(0, 0, 0, 0.1);
  transition: 0.3s ease;
  z-index: 2000;
  display: flex;
  flex-direction: column;
}

.cart.active {
  right: 0;
}

.cart-title {
  text-align: center;
  font-size: 1.8rem;
  font-weight: 600;
  margin: 20px 0;
}

#close-cart {
  position: absolute;
  top: 15px;
  right: 15px;
  font-size: 1.5rem;
  cursor: pointer;
  color: #004f9e;
}

.cart-content {
  flex: 1; /* 📌 take available height */
  overflow-y: auto;
  padding: 0 20px 10px 20px;
}

.cart-box {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #f5f5f5;
  padding: 10px;
  margin-bottom: 15px;
  border-radius: 10px;
}

.cart-img {
  width: 70px;
  height: 70px;
  object-fit: cover;
  border-radius: 5px;
}

.detail-box {
  flex: 1;
  margin-left: 15px;
}

.cart-product-title {
  font-size: 1.1rem;
  font-weight: 500;
}

.cart-price {
  font-size: 1rem;
  color: #666;
  margin: 5px 0;
}

.cart-weight {
  font-size: 0.9rem;
  color: #444;
}

.quantity-controls {
  display: flex;
  align-items: center;
  gap: 5px;
}

.qty-btn {
  font-size: 15px;
  padding: 5px 10px;
  background-color: #fff;
  border: none;
  font-weight: bold;
  cursor: pointer;
  border-radius: 4px;
}

.qty-value {
  font-size: 16px;
  min-width: 20px;
  text-align: center;
}

.cart-remove {
  font-size: 20px;
  color: #fd4646;
  cursor: pointer;
  margin-left: 10px;
}

.cart-sp {
  position: sticky;
  bottom: 0;
  background: white;
  padding: 15px 20px;
  border-top: 1px solid #ddd;
  box-shadow: 0 -2px 5px rgba(0,0,0,0.05);
  z-index: 10;
}


.total {
  display: flex;
  justify-content: space-between;
  font-size: 1.2rem;
  font-weight: bold;
  padding: 10px 0;
  color: #022a45;
}

.cart-imp {
  margin: 10px 0;
}

.times {
  display: block;
  margin-top: 5px;
  font-weight: bold;
  color: #008080;
}

.btn-buy {
  width: 100%;
  padding: 12px;
  margin-top: 15px; /* reduced from 35px */
  background: #004f9e;
  color: white;
  border: none;
  font-size: 16px;
  border-radius: 25px;
  cursor: pointer;
}


.btn-buy:hover {
  background: #171427;
}

.btn-buy {
  animation: pulse 2s infinite;
}

 
@keyframes pulse {
  0% { transform: scale(1); box-shadow: 0 0 0 rgba(253, 70, 70, 0.7); }
  70% { transform: scale(1.05); box-shadow: 0 0 10px rgba(253, 70, 70, 0.7); }
  100% { transform: scale(1); box-shadow: 0 0 0 rgba(253, 70, 70, 0.7); }
}

#close-cart:hover {
  transform: rotate(180deg);
  transition: transform 0.5s ease;
}

/* order form*/

.order-form {
  display: none;
  position: fixed;
  top: 0; left: 0;
  width: 100%; height: 100%;
  background: rgba(0, 0, 0, 0.6);
  z-index: 200;
  justify-content: center;
  align-items: center;
}

.order-form.active {
  display: flex;
}

.form-content {
  background: white;
  padding: 30px;
  border-radius: 10px;
  width: 90%;
  max-width: 400px;
  text-align: center;
}

.form-content input,
.form-content textarea {
  width: 100%;
  margin: 10px 0;
  padding: 10px;
  border: 1px solid #aaa;
  border-radius: 5px;
  font-size: 16px;
}

.order-btn {
  padding: 10px 20px;
  background: #022a45;
  color: white;
  border: none;
  border-radius: 20px;
  cursor: pointer;
}

.order-btn:hover {
  background-color: #008080;
}

.close-btn {
  padding: 10px 20px;
  background: #ccc;
  color: black;
  border: none;
  border-radius: 20px;
  cursor: pointer;
}

.close-btn:hover {
  background: #999;
}


/* product */
.section {
 padding: 50px;
  text-align: center;
} 

.food {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
      padding: 20px;
    }

    .food-img {
  background: white;
  border-radius: 10px;
  width: 200px;
  height: 300px; /* ✅ Fixed height to avoid shifting */
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
  padding: 10px;
  text-align: center;
  position: relative;
  transition: transform 0.3s ease, box-shadow 0.3s ease; /* ✅ Smooth animation */
  will-change: transform;                                                                              
}
          
.food-img:hover {
  transform: translateY(-6px);
  background: white; /* background same रहे */
  border: 2px solid transparent; /* gradient border के लिए */
  border-radius: 10px; /* ✅ rounded border */
  border-image: linear-gradient(135deg, #022a45, #004f9e);
  border-image-slice: 1;
  box-shadow: 0 12px 28px rgba(0, 79, 158, 0.15); /* हल्का shadow */                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
}


.food-img img {
  max-width: 100%;
  height: 150px;
  object-fit: contain;
}


    .discount-badge {
      position: absolute;
      top: 8px;
      left: 8px;
      background: orange;
      color: white;
      font-size: 12px;
      padding: 4px 6px;
      border-radius: 5px;
      font-weight: bold;
    }

    .food-text h1.title {
   font-family: Arial, sans-serif;
  font-size: 18px;
  font-weight: 600;
  color: #222;
  margin-bottom: 6px;
  text-transform: capitalize;
}

    .food-text h3 {
  font-family: 'Inter', sans-serif;
  font-size: 15px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  margin-bottom: 10px;
  font-weight: 500;
}


   .price-value {
  color: #008000; /* Green */
  font-weight: 700;
  font-size: 15px;
}

.old-price {
  text-decoration: line-through;
  color: #999;
  font-size: 13px;
  font-weight: 400;
}

.weight-value {
  color: #666;
  font-size: 13px;
  font-weight: 400;
}

    .btn {
  display: inline-block;
  padding: 10px 20px;
  background: linear-gradient(135deg, #022a45, #004f9e);
  color: white;
  border: none;
  border-radius: 30px;
  font-size: 14px;
  font-weight: 600;
  letter-spacing: 0.5px;
  cursor: pointer;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  transition: all 0.3s ease;
}

.btn:hover {
  background: linear-gradient(135deg, #004f9e, #022a45);
  transform: scale(1.05);
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.25);
}

.btn:active {
  transform: scale(0.96);
}

.btn.added {
  background: linear-gradient(135deg, #2e7d32, #43a047); /* Green shade for added */
  cursor: default;
  box-shadow: none;
}

/* 🌟 Animate card  */

.food-img {
  opacity: 0;
  transform: translateY(40px);
  animation: fadeUp 0.8s ease-out forwards;
  animation-delay: var(--delay, 0s);
}

@keyframes fadeUp {
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 🌀 Add button pulse */
.btn {
  position: relative;
  overflow: hidden;
  animation: popIn 0.4s ease-out;
}
@keyframes popIn {
  0% {
    transform: scale(0.8);
    opacity: 0;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}

/* 🧠 Button added state */
.btn.added {
  background: linear-gradient(135deg, #2e7d32, #43a047);
  cursor: default;
  pointer-events: none;
  font-weight: bold;
  padding: 10px 20px;
  color: white;
}


/* 🛒 Cart icon pulse */
.icon.pulse {
  animation: cartPulse 0.6s ease;
}
@keyframes cartPulse {
  0% { transform: scale(1); }
  50% { transform: scale(1.15); }
  100% { transform: scale(1); }
}

/* 🧾 Signup Modal Animation */
#signupModal > div {
  animation: fadeUp 0.5s ease;
}

@media (max-width: 420px) {

  /* HEADER MAIN ROW FIXED */
  .header-container {
    flex-direction: row !important;
    align-items: center;
    justify-content: space-between;
    padding: 10px 12px;
    flex-wrap: nowrap;
  }

  .left img {
    height: 45px;
  }

  .right {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 10px;
  width: auto;
}

.signup-btn {
  font-size: 13px;
  padding: 6px 10px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 6px;
}

.icon {
  font-size: 1.5rem;
  position: relative;
}

.cart-count {
  position: absolute;
  top: -8px;
  right: -10px;
  background: red;
  color: white;
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 50%;
}


   /* SEARCH STAYS BELOW */
  .middle {
    width: 100%;
    padding: 0 10px;
    margin-top: 10px;
  }

  .search-container {
    width: 100%;
  }

  #searchInput {
    font-size: 13px;
    padding: 10px 16px;
    border: 2px solid #ccc;
    border-radius: 20px;
    width: 100%;
  }

  /* PRODUCT SECTION */
  .section {
    padding: 20px 12px;
  }

  .food {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    gap: 14px;
  }

  .food-img {
    width: 48%;
    padding: 10px;
    border-radius: 12px;
    background: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.08);
  }

  .food-img img {
    height: 130px;
    width: 100%;
    object-fit: contain;
    margin-bottom: 8px;
  }

  .food-text h1 {
    font-size: 14px;
    text-align: center;
    margin: 6px 0;
  }

  .food-text h3 {
    font-size: 13px;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 5px;
  }

  .price-value {
    font-size: 14px;
    color: green;
  }

  .old-price {
    font-size: 12px;
    text-decoration: line-through;
    color: #888;
  }

  .weight-value {
    font-size: 12px;
    color: #333;
  }

  .btn {
    font-size: 13px;
    padding: 8px 16px;
    margin-top: 10px;
    border-radius: 20px;
    background: #003cff;
    color: white;
    display: block;
    width: 100%;
    text-align: center;
    transition: 0.3s;
  }

  .btn:hover {
    background-color: #001f9a;
  }
}
</style>


<!-- 🔍 JS Search Bar Script -->
<script>
document.getElementById("searchInput").addEventListener("input", function () {
  let query = this.value.toLowerCase();
  let products = document.querySelectorAll(".food-img");

  products.forEach(product => {
    let title = product.querySelector("h1").innerText.toLowerCase();
    if (title.includes(query)) {
      product.style.display = "block";
    } else {
      product.style.display = "none";
    }
  });
});

function submitSignup() {
  const name = document.getElementById("signupName").value;
  const phone = document.getElementById("signupPhone").value;

  fetch('signup.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, phone })
  })
  .then(res => res.text())
  .then(msg => {
    alert(msg);

    // ✅ Set login flag after successful signup
    localStorage.setItem("userLoggedIn", "true");

    location.reload(); // या window.location.href = "home.php";
  });
}


<!-- ✅ JavaScript to handle modal toggle -->
// Open the form (you can trigger this from your cart/order button)
function openOrderForm() {
  document.getElementById("orderForm").classList.add("active");
}

// Close form
document.getElementById("closeForm").addEventListener("click", () => {
  document.getElementById("orderForm").classList.remove("active");
});

// Handle form submission
document.getElementById("checkoutForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = this.name.value.trim();
  const phone = this.phone.value.trim();
  const address = this.address.value.trim();

  // Assume you have products in cartData variable (you need to define it earlier in JS)
  const orderData = {
    name: name,
    phone: phone,
    address: address,
    location: document.getElementById("locationLink").value || '',
    products: cartData  // ← this should be defined before with product info
  };

  fetch("save_order.php", {
    method: "POST",
    body: JSON.stringify(orderData),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(res => res.text())
    .then(response => {
      alert(response);
      document.getElementById("orderForm").classList.remove("active");
    })
    .catch(err => {
      alert("Failed to submit order.");
      console.error(err);
    });
});


// 🌟 Scroll animation for product cards
window.addEventListener('scroll', () => {
  document.querySelectorAll('.food-img').forEach((el, i) => {
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight - 100) {
      el.style.setProperty('--delay', `${i * 0.1}s`);
      el.classList.add('visible');
    }
  });
});
// ✅ Animate add to cart button & icon
document.querySelectorAll('.btn').forEach(btn => {
  btn.addEventListener('click', function () {
    this.innerText = "✓ Added";
    this.classList.add('added');
    this.disabled = true;

    // Animate cart icon
    const cartIcon = document.querySelector('.icon');
    cartIcon.classList.add('pulse');
    setTimeout(() => cartIcon.classList.remove('pulse'), 500);
  });
});
</script>

<script src="assets/justpic.js"></script>

</body>
</html>
