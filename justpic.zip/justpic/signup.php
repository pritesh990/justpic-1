<?php
include("includes/db.php");
include("includes/session.php");

$data = json_decode(file_get_contents("php://input"), true);

$name = trim($data['name']);
$phone = trim($data['phone']);

if (!$name || !$phone) {
    http_response_code(400);
    echo "Name and phone are required.";
    exit;
}

// Check if phone already exists
$stmt = $conn->prepare("SELECT * FROM users WHERE phone = ?");
$stmt->bind_param("s", $phone);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Login instead of signup
    $_SESSION['user'] = $result->fetch_assoc();
    echo "Welcome back!";
    exit;
}

// Insert new user
$stmt = $conn->prepare("INSERT INTO users (name, phone) VALUES (?, ?)");
$stmt->bind_param("ss", $name, $phone);
$stmt->execute();

$_SESSION['user'] = ['name' => $name, 'phone' => $phone];
echo "Signup successful!";
?>
