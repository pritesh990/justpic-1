<?php
include("includes/db.php");

$order = null;
$items = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $order_id = $conn->real_escape_string(trim($_POST['order_id']));
  $phone = $conn->real_escape_string(trim($_POST['phone']));

  // ✅ Use 'order_id' instead of 'id'
  $stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ? AND phone = ?");
  $stmt->bind_param("ss", $order_id, $phone); // both are strings now
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result->num_rows > 0) {
    $order = $result->fetch_assoc();

    // Get internal numeric ID to fetch items
    $order_db_id = $order['id'];

    // ✅ Now get order items using internal ID
    $itemStmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
    $itemStmt->bind_param("i", $order_db_id);
    $itemStmt->execute();
    $items = $itemStmt->get_result();
  }
}
?>

<!-- HTML Part -->
<!DOCTYPE html>
<html>
<head>
  <title>Track Your Order - Justpic</title>
  <link rel="stylesheet" href="assets/justpic.css" />
  <style>
    body { font-family: Arial; padding: 30px; background: #f9f9f9; }
    input { padding: 10px; margin-right: 10px; }
    button { padding: 10px 15px; background: #002244; color: #fff; border: none; }
    .error { color: red; font-weight: bold; margin-top: 20px; }
    .success { color: green; font-weight: bold; margin-top: 20px; }
  </style>
</head>
<body>

<h2>📦 Track Your Order</h2>

<form method="POST">
  <input type="text" name="order_id" placeholder="Enter Order ID" required value="<?= htmlspecialchars($_POST['order_id'] ?? '') ?>">
  <input type="text" name="phone" placeholder="Enter Phone" required value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
  <button type="submit">Check Order</button>
</form>

<?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
  <?php if ($order): ?>
    <div class="success">
      ✅ Order Found!<br>
      <strong>Name:</strong> <?= htmlspecialchars($order['customer_name']) ?><br>
      <strong>Phone:</strong> <?= htmlspecialchars($order['phone']) ?><br>
      <strong>Address:</strong> <?= htmlspecialchars($order['address']) ?><br>
      <strong>Total:</strong> ₹<?= number_format($order['total_amount'], 2) ?><br>
      <strong>Items:</strong>
      <ul>
        <?php while($item = $items->fetch_assoc()): ?>
          <li><?= htmlspecialchars($item['product_name']) ?> (<?= $item['weight'] ?>) × <?= $item['quantity'] ?> = ₹<?= number_format($item['subtotal'], 2) ?></li>
        <?php endwhile; ?>
      </ul>
    </div>
  <?php else: ?>
    <div class="error">❌ Order not found! Please check Order ID or Phone Number.</div>
  <?php endif; ?>
<?php endif; ?>

</body>
</html>
