

<?php
include("includes/db.php");

// Get JSON body
$data = json_decode(file_get_contents("php://input"), true);

// Validate required fields
if (
    !$data ||
    empty($data['products']) ||
    empty($data['name']) ||
    empty($data['phone']) ||
    empty($data['address'])
) {
    http_response_code(400);
    echo "Invalid data";
    exit;
}


// Sanitize user input
$name     = $conn->real_escape_string(trim($data['name']));
$phone    = $conn->real_escape_string(trim($data['phone']));
$address  = $conn->real_escape_string(trim($data['address']));
$location = $conn->real_escape_string(trim($data['location'] ?? ''));
$order_date = date("Y-m-d");
$total_amount = 0.0;

// Generate unique order_id like 280625001
$today = date("dmy");
$query = "SELECT MAX(order_id) AS last_id FROM orders WHERE order_id LIKE '$today%'";
$result = $conn->query($query);
$row = $result->fetch_assoc();

$newNumber = 1;
if ($row['last_id']) {
    $lastNumber = intval(substr($row['last_id'], 6));
    $newNumber = $lastNumber + 1;
}
$numeric_order_id = $today . str_pad($newNumber, 3, '0', STR_PAD_LEFT);

// Calculate total order amount
foreach ($data['products'] as $item) {
    $total_amount += isset($item['subtotal']) ? floatval($item['subtotal']) : 0;
}


// Insert into orders table
$stmt = $conn->prepare("
    INSERT INTO orders (order_id, customer_name, phone, address, location_link, total_amount, order_date)
    VALUES (?, ?, ?, ?, ?, ?, ?)
");
$stmt->bind_param("sssssss", $numeric_order_id, $name, $phone, $address, $location, $total_amount, $order_date);
$stmt->execute();
$order_row_id = $stmt->insert_id;
$stmt->close();

// Insert products into order_items table
foreach ($data['products'] as $item) {
    $product_name = $conn->real_escape_string($item['name']);
    $price        = floatval($item['price']);
    $weight       = $conn->real_escape_string($item['weight']);
    $quantity     = intval($item['quantity']);
    $subtotal     = isset($item['subtotal']) ? floatval($item['subtotal']) : 0;

    $stmt = $conn->prepare("
        INSERT INTO order_items (order_id, product_name, price, weight, quantity, subtotal)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("isdssd", $order_row_id, $product_name, $price, $weight, $quantity, $subtotal);
    $stmt->execute();
    $stmt->close();
}


echo "✅ Order placed successfully! Order ID: $numeric_order_id";
?>
