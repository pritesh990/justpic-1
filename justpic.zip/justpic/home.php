<?php include("includes/session.php"); ?>

<?php include("includes/db.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Justpic – Fastest Vegetable Delivery</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
   body {
  font-family: Arial, sans-serif;
  background: #fff;
  padding-top: 100px; /* ⭐ enough space for fixed header */
}

   .head {
  background: white;
  padding: 10px 20px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: fixed; /* ⭐ FIXED */
  top: 0;
  left: 0;
  width: 100%;
  z-index: 9999;
}

    .logo img {
  max-height: 60px;
  margin-left: 2rem; /* was 7rem */
}


.nav-container {
  display: flex;
  justify-content: center; /* centers the links */
  align-items: center;
  margin-top: 10px;
  margin-bottom: 10px;
   
}

.nav-links {
  display: flex;
  gap: 25px; /* space between buttons */
  align-items: center;
  flex-wrap: wrap; /* for small screens */
}

.nav-btn {
  text-decoration: none;
  font-weight: bold;
  color: #333;
  padding: 8px 16px;
  border-radius: 6px;
  transition: background 0.3s ease, color 0.3s ease;
  font-size: 16px;
}

.nav-btn:hover {
  background-color: #f0f0f0;
  color: #007bff;
}

    .signup-btn {
      margin-right: 7rem;
      padding: 10px 20px;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      text-decoration: none;
      font-weight: bold;
      transition: background 0.3s ease;
    }
    .signup-btn:hover {
      background: #0056b3;
    }
    .hero {
      background: #f9f9f9;
      margin: 20px;
      position: relative;
      overflow: hidden;
      text-align: center;
      height: 70vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }

  
  #signupModal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(4px);
    z-index: 999;
    animation: fadeIn 0.3s ease-in-out;
  }

  #signupModal > div {
    background: #fff;
    max-width: 420px;
    margin: 80px auto;
    padding: 25px 30px;
    border-radius: 12px;
    position: relative;
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    animation: slideIn 0.4s ease-in-out;
  }

  #signupModal h3 {
    margin-top: 0;
    font-size: 20px;
    font-weight: 600;
    color: #333;
    text-align: center;
  }

  #signupModal input {
    width: 100%;
    padding: 12px;
    margin-top: 12px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 14px;
    transition: border 0.3s;
  }

  #signupModal input:focus {
    outline: none;
    border-color: #4CAF50;
    box-shadow: 0 0 5px #4CAF50;
  }

  #signupModal button {
    padding: 10px 22px;
    margin-top: 15px;
    border: none;
    background: #4CAF50;
    color: white;
    font-size: 14px;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s;
  }

  #signupModal button:hover {
    background: #43a047;
  }

  #signupModal button:last-child {
    position: absolute;
    top: 12px;
    right: 12px;
    background: transparent;
    color: #888;
    font-size: 18px;
    padding: 0;
    width: 32px;
    height: 32px;
    line-height: 32px;
    border-radius: 50%;
    transition: background 0.3s, color 0.3s;
  }

  #signupModal button:last-child:hover {
    background: #f2f2f2;
    color: #000;
  }

  @keyframes fadeIn {
    from {opacity: 0;}
    to {opacity: 1;}
  }

  @keyframes slideIn {
    from {transform: translateY(-30px); opacity: 0;}
    to {transform: translateY(0); opacity: 1;}
  }



    .hero video {
      position: absolute;
      top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; z-index: 0;
    }
    .hero::after {
      content: "";
      position: absolute;
      top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 1;
    }
    .hero h1, .hero p {
      position: relative;
      z-index: 2;
    }
   
.hero h1.animated {
  font-size: 4rem;
  color: #fff;
  text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.8);
  opacity: 0;
  animation: slideUpFade 2s ease-out 0.5s forwards;
}


/* Animation keyframes */
@keyframes zoomFadeIn {
  0% {
    opacity: 0;
    transform: scale(0.6);
  }
  60% {
    opacity: 1;
    transform: scale(1.1);
  }
  100% {
    transform: scale(1);
  }
}
   
    .hero p {
      font-size: 1.2rem;
      color: #fff;
      text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.8);
    }
    .hero p.animated {
  animation: slideUpFade 2s ease-out 0.5s forwards;
  opacity: 0;
}


    @keyframes slideUpFade {
  0% {
    opacity: 0;
    transform: translateY(40px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}


    .category-section {
  padding: 40px 20px;
  background: #f9f9f9;
  text-align: center;
}

.category-heading {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 30px;
  color: #333;
}

.category-grid {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 30px;
}

.category-box {
  text-decoration: none;
  color: #111;
  width: 120px;
  transition: transform 0.3s ease;
}

.category-box:hover {
  transform: translateY(-6px);
}

.icon-circle {
  background: #f5f5f5;
  border-radius: 50%;
  width: 100px;
  height: 100px;
  margin: 0 auto 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  transition: box-shadow 0.3s ease, background 0.3s ease;
}

.icon-circle:hover {
  background: #ffeaea;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
}

.icon-circle img {
  width: 50px;
  height: 50px;
  object-fit: contain;
}

.category-box span {
  font-size: 14px;
  font-weight: 600;
  display: block;
}
    .features {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  padding: 40px 20px;
  background: #f9f9f9;
  text-align: center;
}

.section-title {
  width: 100%;
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 30px;
  color: #333;
}

.feature-box {
  width: 250px;
  margin: 15px;
  padding: 20px;
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

.feature-box i {
  font-size: 32px;
  margin-bottom: 10px;
  color: #4CAF50;
}
    /* Info Bar Section Above Footer */
.info-bar {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  gap: 30px;
  padding: 25px 10px;
  border-top: 1px solid #ddd;
  border-bottom: 1px solid #ddd;
  background-color: #f9f9f9;
}

.info-item {
  display: flex;
  align-items: center;
  font-size: 15px;
  color: #333;
  gap: 10px;
}

.info-item i {
  font-size: 18px;
  color: #222;
}

.contact-cards {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 30px;
  padding: 50px 20px;
  background-color: #002b45; /* Gradient background */
  animation: fadeIn 1s ease forwards;
}

.contact-card {
  flex: 1 1 280px;
  background-color: #ffffff;
  padding: 30px 25px;
  border-radius: 16px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
  text-align: left;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  animation: slideUp 0.8s ease forwards;
}

.contact-card:hover {
  transform: translateY(-10px);
  box-shadow: 0 16px 32px rgba(0, 0, 0, 0.2);
}

.contact-card h5 {
  font-size: 16px;
  color: #777;
  margin-bottom: 8px;
  text-transform: uppercase;
  letter-spacing: 0.6px;
}

.contact-card h2 {
  font-size: 26px;
  font-weight: bold;
  color: #1e3c72;
  margin-bottom: 12px;
}

.contact-card p {
  font-size: 15px;
  color: #444;
  margin-bottom: 15px;
  line-height: 1.5;
}

.contact-card a {
  font-weight: bold;
  text-decoration: none;
  color: #007bff;
  border-bottom: 2px solid transparent;
  transition: border-color 0.3s, color 0.3s;
}

.contact-card a:hover {
  border-color: #007bff;
  color: #0056b3;
}



/* Footer Styles */
.footer {
  background-color: #002b45;
  color: #fff;
  padding: 40px 20px;
  font-family: 'Segoe UI', sans-serif;
}

.footer-top {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 40px;
  margin-bottom: 30px;
  text-align: left;
}

.footer-box h4 {
  color: #a8d5e2;
  margin-bottom: 15px;
  font-size: 18px;
  border-bottom: 1px solid #4b748d;
  padding-bottom: 5px;
}

.footer-box ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.footer-box ul li {
  margin-bottom: 10px;
}

.footer-box ul li a {
  color: #d5ecf3;
  text-decoration: none;
  transition: color 0.3s ease;
}

.footer-box ul li a:hover {
  color: #ffffff;
}

.footer-bottom {
  border-top: 1px solid #3b5e6b;
  padding-top: 20px;
  text-align: center;
}

.footer-links a {
  color: #a8d5e2;
  margin: 0 12px;
  text-decoration: none;
  font-size: 15px;
  transition: color 0.3s ease;
}

.footer-links a:hover {
  color: #fff;
}

.footer-social {
  margin-top: 20px;
}

.footer-social a {
  display: inline-block;
  margin:0 8px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: transparent;
  border: 1px solid #ccc;
  color: #a674d0;
  text-align: center;
  transition: all 0.3s ease;
}
.footer-social i{
  font-size:20px;
}

.footer-social a:hover {
  background: #a674d0;
  color: #fff;
  border-color: #a674d0;
}




    .signup-btn {
    background: #0d6efd;
    color: white;
    padding: 8px 16px;
    border-radius: 6px;
    border: none;
    cursor: pointer;
    transition: 0.3s ease;
  }
  .signup-btn:hover {
    background: #0b5ed7;
  }

  /* animation */
  /* Animation Base Classes */
@keyframes fadeInUp {
  0% { opacity: 0; transform: translateY(30px); }
  100% { opacity: 1; transform: translateY(0); }
}

@keyframes slideUp {
  0% { opacity: 0; transform: translateY(60px); }
  100% { opacity: 1; transform: translateY(0); }
}

@keyframes fadeIn {
  0% { opacity: 0; }
  100% { opacity: 1; }
}


/* Category Box animation */
.category-box {
  animation: slideUp 1.3s ease-in-out;
}

/* Features animation delay */
.feature-box {
  opacity: 0;
  transform: translateY(40px);
  animation: fadeInUp 1s ease forwards;
}
.feature-box:nth-child(1) { animation-delay: 0.6s; }
.feature-box:nth-child(2) { animation-delay: 0.9s; }
.feature-box:nth-child(3) { animation-delay: 1.1s; }
.feature-box:nth-child(4) { animation-delay: 1.6s; }

/* Modal animation */
#signupModal > div {
  animation: fadeInUp 0.5s ease-out;
}

/* ==== Contact Card Animation ==== */
.contact-card {
  opacity: 0;
  transform: translateY(40px);
  transition: all 0.6s ease-in-out;
}

/* Animate visible ones */
.contact-card.visible {
  opacity: 1;
  transform: translateY(0);
}

/* Add delay to each card */
.contact-card:nth-child(1) {
  transition-delay: 0.1s;
}
.contact-card:nth-child(2) {
  transition-delay: 0.3s;
}
.contact-card:nth-child(3) {
  transition-delay: 0.5s;
}

.hamburger {
  display: none;
  font-size: 24px;
  cursor: pointer;
  z-index: 10000;
  margin-right: 15px;
}

@media (max-width: 420px) {
  .head {
    padding: 8px 10px;
    justify-content: space-between;
     align-items: center;
  }

  .logo img {
    max-height: 36px;
    margin-left: 5px;
  }

  .signup-btn {
    padding: 6px 12px;
    font-size: 13px;
    margin-right: 5px;
  }


}


  </style>
</head>
<body>
  <header class="head">
    
    <div class="logo">
      <img src="uploads/logo.png" alt="Logo">
    </div>

    
  <?php if (isset($_SESSION['user'])): ?>
  <span>👋 Welcome, <?= htmlspecialchars($_SESSION['user']['name']) ?></span>
  <a href="logout.php" class="signup-btn" style="margin-left:10px;">LOGOUT</a>
<?php else: ?>
  <div class="top-bar">
 <button class="signup-btn" onclick="document.getElementById('signupModal').style.display='block'">SIGNUP</button>

</div>
<?php endif; ?>

   



<div id="signupModal">
  <div>
    <h3>Signup to continue</h3>
    <input id="signupName" placeholder="Your Name">
    <input id="signupPhone" placeholder="Phone Number">
    <button onclick="submitSignup()">Submit</button>
    <button onclick="document.getElementById('signupModal').style.display='none'">✖</button>
  </div>
</div>


</div>

  </header>

<!-- 🔽 Add this after .logo -->
<div class="nav-container">
  <div class="nav-links">
    <a href="home.php" class="nav-btn">Home</a>
    <a href="veg_fru.php" class="nav-btn">Vegetables</a>
    <a href="fruits.php" class="nav-btn">Fruits</a>
    <a href="#about" class="nav-btn">About Us</a>
    <a href="#contact" class="nav-btn">Contact</a>
  </div>
</div>

<div class="hamburger" onclick="toggleMenu()">☰</div>

  <section class="hero">
    <video autoplay muted loop>
      <source src="assets/background.mp4" type="video/mp4">
      Your browser does not support the video tag.
    </video>
    <h1 class="animated">Welcome To Justpic</h1>
    <p class="animated">Get the freshest vegetables delivered to your doorstep in minutes. Powered by local farms and super-fast delivery.</p>
  </section>

  <section class="category-section">
  <h2 class="category-heading">FEATURED CATEGORIES</h2>
  <div class="category-grid">
    <a href="veg_fru.php" class="category-box">
      <div class="icon-circle">
        <img src="https://cdn-icons-png.flaticon.com/512/415/415733.png" alt="Vegetables">
      </div>
      <span>VEGETABLES</span>
    </a>

    <a href="fruits.php" class="category-box">
      <div class="icon-circle">
        <img src="https://cdn-icons-png.flaticon.com/512/2909/2909765.png" alt="Fruits">
      </div>
      <span>FRUITS</span>
    </a>
  </div>
</section>


  <section class="features"id="about">
  <h2 class="section-title">WHY JUSTPIC?</h2>

  <div class="feature-box">
    <i class="fas fa-truck"></i>
    <h3>FAST DELIVERY</h3>
    <p>Get your veggies delivered in under 15 minutes!</p>
  </div>
  <div class="feature-box">
    <i class="fas fa-seedling"></i>
    <h3>FRESHESHTY QUALITY</h3>
    <p>Only handpicked, farm-fresh vegetables.</p>
  </div>
  <div class="feature-box">
    <i class="fas fa-tags"></i>
    <h3>DAILY OFFERS</h3>
    <p>Save big with daily discounts and special deals.</p>
  </div>
  <div class="feature-box">
    <i class="fas fa-map-marker-alt"></i>
    <h3>LIVE ORDERS TRACKING</h3>
    <p>Know where your order is with live status.</p>
  </div>
</section>

<section class="contact-cards"id="contact">
  <div class="contact-card whatsapp">
    <h5>📞 PHONE & WHATSAPP</h5>
    <h2>9054887337</h2>
    <p>Call or message us anytime on WhatsApp for quick order help and updates.</p>
    <a href="https://wa.me/919054887337" target="_blank">Chat on WhatsApp</a>
  </div>

  <div class="contact-card support">
    <h5>📬 EMAIL & SUPPORTS</h5>
    <h2>support@justpic.com</h2>
    <p>Have questions or issues? Reach out to our support team anytime.</p>
    <a href="mailto:support@justpic.com">Send Email</a>
  </div>

  <div class="contact-card hours">
    <h5>🕒 WORKING HOURS</h5>
    <h2>6:00 AM – 10:00 PM</h2>
    <p>We deliver fresh vegetables every day. Orders accepted throughout the day.</p>
    <a href="#about">Know More</a>
  </div>
</section>


  <!-- Info Section Above Footer -->
<section class="info-bar">
  <div class="info-item">
    <i class="fas fa-tshirt"></i>
    <span>Everyday fresh products</span>
  </div>
  <div class="info-item">
    <i class="fas fa-truck"></i>
    <span>Free delivery for order over ₹70</span>
  </div>
  <div class="info-item">
    <i class="fas fa-star"></i>
    <span>Daily Mega Discounts</span>
  </div>
  <div class="info-item">
    <i class="fas fa-tags"></i>
    <span>Best price on the market</span>
  </div>
</section>

<!-- Stylish Footer -->
<footer class="footer">
  <div class="footer-top">
    <div class="footer-box">
      <h4>VEGETABLES</h4>
      <ul>
        <li><a href="#">Fresh Vegetables</a></li>
        <li><a href="#">Cuts & Sprouts</a></li>
        <li><a href="#">Herbs & Seasonings</a></li>
        <li><a href="#">Packaged Produce</a></li>
      </ul>
    </div>
    <div class="footer-box">
      <h4>FRUITS</h4>
      <ul>
        <li><a href="#">Fresh Fruits</a></li>
        <li><a href="#">Exotic Fruits</a></li>
        <li><a href="#">Cuts & Packs</a></li>
        <li><a href="#">Party Trays</a></li>
      </ul>
    </div>
  </div>

  <div class="footer-bottom">
    <p>&copy; <?= date('Y') ?> Justpic. All rights reserved.</p>
    <div class="footer-links">
      <a href="index.php">Home</a>
      <a href="track_order.php">Track Order</a>
      <a href="#">About Us</a>
      <a href="#">Contact</a>
    </div>

     <div class="footer-social">
      <a href="#"><i class="fab fa-facebook-f"></i></a>
      <a href="#"><i class="fab fa-twitter"></i></a>
      <a href="#"><i class="fab fa-instagram"></i></a>
    </div>

  </div>
</footer>

</body>
</html>

<script>
  const openBtn = document.getElementById("openSignup");
  const closeBtn = document.getElementById("closeSignup");
  const modal = document.getElementById("signupModal");

  openBtn.addEventListener("click", () => {
    modal.style.display = "flex";
  });

  closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
  });

  // Close modal on outside click
  window.addEventListener("click", (e) => {
    if (e.target === modal) {
      modal.style.display = "none";
    }
  });


 function submitSignup() {
  const name = document.getElementById("signupName").value;
  const phone = document.getElementById("signupPhone").value;

  fetch('signup.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, phone })
  })
  .then(res => res.text())
  .then(msg => {
    alert(msg);

    // ✅ Set login flag after successful signup
    localStorage.setItem("userLoggedIn", "true");

    location.reload(); // या window.location.href = "home.php";
  });
}

/* animation css */
function revealOnScroll() {
    const elements = document.querySelectorAll('.feature-box');
    const triggerBottom = window.innerHeight / 1.2;

    elements.forEach(el => {
      const boxTop = el.getBoundingClientRect().top;
      if (boxTop < triggerBottom) {
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
      }
    });
  }


  window.addEventListener('scroll', revealOnScroll);
  window.addEventListener('load', revealOnScroll); // Initial load animation
  function animateContactCards() {
    const cards = document.querySelectorAll(".contact-card");
    const triggerBottom = window.innerHeight * 0.9;

    cards.forEach(card => {
      const cardTop = card.getBoundingClientRect().top;
      if (cardTop < triggerBottom) {
        card.classList.add("visible");
      }
    });
  }

  window.addEventListener("scroll", animateContactCards);
  window.addEventListener("load", animateContactCards);

  
  function toggleMenu() {
    document.querySelector('.nav-links').classList.toggle('show');
  }


</script>